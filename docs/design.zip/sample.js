// Shared ToNoteDo sample content — one realistic library slice used by every
// style so the only thing that changes between artboards is the visual system.
window.TND = {
  // Sidebar group tree (a personal library). `views` are the fixed nav rows
  // above the group tree; `tree` is the multi-level group hierarchy (0003).
  views: [
    { id: 'calendar', label: 'Calendar', icon: 'calendar' },
    { id: 'search', label: 'Search', icon: 'search', hint: '⌘P' },
  ],
  tree: [
    { id: 'work', label: 'Work', icon: 'folder', color: '#C06A4A', count: 23, open: true, children: [
      { id: 'atlas', label: 'Project Atlas', icon: 'folder', color: '#C06A4A', count: 9, selected: true },
      { id: 'meetings', label: 'Meetings', icon: 'folder', count: 11 },
    ]},
    { id: 'reading', label: 'Reading', icon: 'book', count: 41 },
    { id: 'journal', label: 'Journal', icon: 'pen', count: 128 },
    { id: 'ideas', label: 'Ideas', icon: 'spark', count: 17 },
  ],
  // Entry list for the selected group (Project Atlas). `done` drives task-like
  // styling; `due` puts the entry on the calendar.
  group: { label: 'Project Atlas', path: 'Work / Project Atlas', count: 9 },
  entries: [
    { id: 'kickoff', title: 'Kickoff sync — Atlas', preview: 'Scope confirmed with the team. Milestone plan drafted; vendor shortlist…', due: 'Today', tags: ['atlas', 'decided'], people: ['maya'], selected: true, tasks: { done: 2, total: 4 } },
    { id: 'spec-review', title: 'Spec review notes', preview: 'Editor rendering model settled on live-inline. Open question on outline…', due: 'Jun 12', tags: ['atlas', 'spec'], people: ['sergey'] },
    { id: 'q3-milestones', title: 'Q3 milestones', preview: 'M1 index pipeline · M2 calendar · M3 plugins. Dates pending vendor pick.', due: 'Jun 30', tags: ['atlas', 'planning'], done: false, tasks: { done: 1, total: 6 } },
    { id: 'vendor', title: 'Vendor comparison', preview: 'Three providers evaluated against sync + cost. Leaning toward option B.', tags: ['atlas', 'research'], people: ['maya', 'lee'] },
    { id: 'retro-4', title: 'Retro — sprint 4', preview: 'What went well, what to change. Carry: tighten the reconciliation budget.', due: 'Jun 6', tags: ['atlas'], people: ['sergey', 'lee', 'maya'] },
    { id: 'naming', title: 'Naming + positioning', preview: 'Calm, fast, private. Avoid the "database feeling." Draft the one-liner.', tags: ['atlas', 'ideas'] },
  ],
  // The open entry, as parsed markdown blocks. The editor renders these with
  // live-inline formatting; tokens (#tag, @mention, [[wikilink]]) stay literal.
  open: {
    title: 'Kickoff sync — Atlas',
    slug: 'work/atlas/kickoff-sync',
    saved: 'saved',
    blocks: [
      { t: 'p', runs: [
        { s: 'Scope confirmed with ' }, { mention: 'maya' }, { s: '. Marking this ' }, { tag: 'decided' },
        { s: ' — the live-inline editor wins over split-preview. Full notes in ' }, { link: 'spec-review', text: 'Spec review notes' }, { s: '.' },
      ]},
      { t: 'h2', text: 'Action items' },
      { t: 'task', done: true, runs: [{ s: 'Confirm scope with ' }, { mention: 'maya' }] },
      { t: 'task', done: true, runs: [{ s: 'Lock the markdown dialect ' }, { tag: 'decided' }] },
      { t: 'task', done: false, runs: [{ s: 'Draft milestone plan → ' }, { link: 'q3-milestones', text: 'Q3 milestones' }] },
      { t: 'task', done: false, runs: [{ s: 'Share ' }, { tag: 'atlas' }, { s: ' update with ' }, { mention: 'sergey' }] },
      { t: 'h2', text: 'Notes' },
      { t: 'quote', text: 'Keep it calm and fast. The app is a fast, modern editor — not a database.' },
      { t: 'p', runs: [{ s: 'Vendor pick blocks the dates. Compare options in ' }, { link: 'vendor', text: 'Vendor comparison' }, { s: ' before Friday.' }] },
    ],
  },
  // Typed frontmatter for the properties panel (0002).
  props: [
    { k: 'due', type: 'date', v: '2026-06-10' },
    { k: 'done', type: 'boolean', v: false },
    { k: 'priority', type: 'enum', v: 'High', options: ['Low', 'Medium', 'High'] },
    { k: 'tags', type: 'tag[]', v: ['atlas', 'decided'] },
    { k: 'mentions', type: 'ref[]', v: ['maya', 'sergey'] },
    { k: 'effort', type: 'number', v: 3 },
  ],
  // People for @mention chips and avatars (initials + a stable tint).
  people: {
    maya: { name: 'Maya Chen', initials: 'MC', tint: '#C06A4A' },
    sergey: { name: 'Sergey Z.', initials: 'SZ', tint: '#5B7290' },
    lee: { name: 'Lee Park', initials: 'LP', tint: '#5E9A6E' },
  },
  // Command palette (⌘K) — query "new" with matched + recent rows (0007).
  palette: {
    query: 'new',
    results: [
      { cat: 'Entry', label: 'New entry', bind: '⌘N', icon: 'plus' },
      { cat: 'Entry', label: 'New entry from template', bind: '', icon: 'plus' },
      { cat: 'Group', label: 'New group', bind: '', icon: 'folder' },
      { cat: 'View', label: 'New calendar view', bind: '', icon: 'calendar' },
    ],
    recent: [
      { label: 'Spec review notes', sub: 'Work / Project Atlas', icon: 'doc' },
      { label: 'Q3 milestones', sub: 'Work / Project Atlas', icon: 'doc' },
    ],
  },
  // Mini-calendar peek: June 2026. `due` marks days with entries; `today` = 10.
  cal: { month: 'June 2026', today: 10, start: 0 /* Jun 1 = Mon? layout handles */, days: 30, due: [6, 10, 12, 18, 30] },
  // Keyboard hints shown in the status bar / accessory row.
  hints: [
    { k: '⌘K', label: 'Commands' },
    { k: '⌘P', label: 'Search' },
    { k: '⌘N', label: 'New entry' },
    { k: '⌥↑↓', label: 'Move block' },
    { k: '?', label: 'Shortcuts' },
  ],
};
