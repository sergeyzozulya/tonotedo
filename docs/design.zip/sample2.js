// Extra sample data for the full Mono build-out. Extends window.TND with the
// content the new screens need. Loaded after sample.js.

// Two more people for the directory / mentions.
window.TND.people.rin = { name: 'Rin Okafor', initials: 'RO', tint: '#8A6BB0' };
window.TND.people.theo = { name: 'Theo Vance', initials: 'TV', tint: '#A9742A' };

window.TND2 = {
  // ── Calendar (June 2026, today = 10) ──────────────────────────────────────
  // Month-grid items keyed by day-of-month.
  calMonth: {
    1: [{ t: 'Plan the week', tag: 'planning' }],
    2: [{ t: '1:1 — Lee', time: '10:00', tag: 'meetings' }],
    6: [{ t: 'Retro — sprint 4', time: '15:00', tag: 'atlas' }],
    9: [{ t: 'Vendor call', time: '11:30', tag: 'research' }],
    10: [{ t: 'Kickoff sync — Atlas', time: '09:30', tag: 'atlas', people: ['maya', 'sergey'] }, { t: 'Review spec', tag: 'spec' }],
    12: [{ t: 'Spec review notes', tag: 'spec', people: ['sergey'] }],
    15: [{ t: 'Standup', time: '09:00', tag: 'meetings', repeat: true }],
    16: [{ t: 'Reading: Deep Work', tag: 'reading' }],
    18: [{ t: 'Design jam', tag: 'ideas', rangeStart: true }],
    19: [{ t: 'Design jam', rangeMid: true }, { t: 'Q3 draft', tag: 'planning' }],
    22: [{ t: 'Standup', time: '09:00', tag: 'meetings', repeat: true }],
    24: [{ t: 'Vendor decision due', tag: 'atlas' }],
    29: [{ t: 'Standup', time: '09:00', repeat: true }],
    30: [{ t: 'Q3 milestones', tag: 'planning' }],
  },
  rangeBand: { start: 18, end: 19, title: 'Design jam', tag: 'ideas' },
  // Week view: Mon–Sun of the current week, timed events (start/end in hours).
  weekCols: [['Mon', 8], ['Tue', 9], ['Wed', 10], ['Thu', 11], ['Fri', 12], ['Sat', 13], ['Sun', 14]],
  weekHours: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
  weekEvents: [
    { day: 0, s: 10, e: 11, t: '1:1 — Lee', tag: 'meetings' },
    { day: 1, s: 9, e: 9.4, t: 'Standup', tag: 'meetings' },
    { day: 2, s: 9.5, e: 10.5, t: 'Kickoff — Atlas', tag: 'atlas' },
    { day: 2, s: 11.5, e: 12, t: 'Vendor call', tag: 'research' },
    { day: 3, s: 9, e: 9.4, t: 'Standup', tag: 'meetings' },
    { day: 4, s: 9, e: 9.4, t: 'Standup', tag: 'meetings' },
    { day: 4, s: 15, e: 16, t: 'Spec review', tag: 'spec' },
    { day: 5, s: 14, e: 18, t: 'Design jam', tag: 'ideas' },
  ],
  // Day view (Wed Jun 10).
  dayEvents: [
    { s: 9, e: 9.4, t: 'Standup', tag: 'meetings' },
    { s: 9.5, e: 10.5, t: 'Kickoff sync — Atlas', tag: 'atlas', people: ['maya', 'sergey'] },
    { s: 11.5, e: 12, t: 'Vendor call', tag: 'research', people: ['lee'] },
    { s: 14, e: 15, t: 'Write Q3 milestones', tag: 'planning' },
  ],
  dayAllDay: [{ t: 'Review spec', tag: 'spec' }],

  // ── Today / agenda ────────────────────────────────────────────────────────
  today: {
    date: 'Wednesday · June 10, 2026',
    overdue: [{ t: 'Vendor comparison', due: 'Jun 6', tags: ['atlas', 'research'], people: ['maya', 'lee'] }],
    now: [
      { t: 'Kickoff sync — Atlas', time: '09:30', tags: ['atlas', 'decided'], people: ['maya', 'sergey'], tasks: { done: 2, total: 4 } },
      { t: 'Review spec', time: 'all-day', tags: ['spec'] },
      { t: 'Vendor call', time: '11:30', tags: ['research'], people: ['lee'] },
    ],
    upcoming: [
      { d: 'Thu 11', items: [{ t: 'Draft milestone plan', tags: ['planning'] }] },
      { d: 'Fri 12', items: [{ t: 'Spec review notes', tags: ['atlas', 'spec'], people: ['sergey'] }] },
      { d: 'Mon 15', items: [{ t: 'Standup', repeat: true }, { t: 'Reading: Deep Work', tags: ['reading'] }] },
    ],
  },

  // ── Search (⌘P) ─────────────────────────────────────────────────────────
  search: {
    query: 'milestone',
    chips: [{ k: 'group', v: 'Project Atlas' }, { k: 'tag', v: 'planning' }, { k: 'has', v: 'due' }],
    counts: { entries: 4, groups: 1, tags: 2 },
    results: [
      { t: 'Q3 milestones', path: 'Work / Project Atlas', snip: 'M1 index pipeline · M2 calendar · M3 plugins. Dates pending vendor pick.', due: 'Jun 30', tags: ['atlas', 'planning'] },
      { t: 'Kickoff sync — Atlas', path: 'Work / Project Atlas', snip: 'Draft milestone plan → see Q3 milestones. Vendor pick blocks the dates.', due: 'Today', tags: ['atlas', 'decided'] },
      { t: 'Roadmap 2026', path: 'Work', snip: 'Quarterly milestones and the bets behind each one.', tags: ['planning'] },
      { t: 'Spec review notes', path: 'Work / Project Atlas', snip: 'Milestone M2 depends on the calendar reschedule write-back.', tags: ['spec'] },
    ],
  },

  // ── Keyboard cheatsheet (?) grouped by category ──────────────────────────
  cheatsheet: [
    { cat: 'Navigation', items: [['Command palette', '⌘K'], ['Search library', '⌘P'], ['Next / prev entry', 'j / k'], ['Open / collapse group', 'o / O'], ['Focus sidebar', '⌘1'], ['Focus editor', '⌘3']] },
    { cat: 'Entry', items: [['New entry', '⌘N'], ['Toggle done', '⌘↵'], ['Archive', '⌘⌫'], ['Open properties', '⌘.'], ['Duplicate', '⌘D']] },
    { cat: 'Editor', items: [['Heading 1 / 2', '⌘⌥1 / 2'], ['Toggle checkbox', '⌘L'], ['Move block ↑ / ↓', '⌥↑ / ↓'], ['Wikilink', '[ ['], ['Tag', '#'], ['Mention', '@']] },
    { cat: 'View', items: [['Calendar M / W / D', '⌘⌥ M/W/D'], ['Toggle outline', '⌘⇧O'], ['Light / dark', '⌘⇧L'], ['Cheatsheet', '?']] },
  ],

  // ── Settings ──────────────────────────────────────────────────────────────
  settings: {
    nav: [['Appearance', 'settings'], ['Editor', 'pen'], ['Keymap', 'doc'], ['Library', 'folder'], ['Plugins', 'spark'], ['About', 'book']],
    active: 'Keymap',
    preset: 'vim-flavor',
    presets: ['default', 'vim-flavor', 'emacs-flavor'],
    bindings: [
      ['entry.create', 'New entry', '⌘N'],
      ['entry.toggle-done', 'Toggle done', '⌘↵'],
      ['nav.palette', 'Command palette', '⌘K'],
      ['nav.search', 'Search library', '⌘P'],
      ['editor.heading-1', 'Heading 1', '⌘⌥1'],
      ['editor.move-block-up', 'Move block up', '⌥↑'],
      ['view.calendar-month', 'Calendar: month', '⌘⌥M'],
      ['app.toggle-theme', 'Toggle light / dark', '⌘⇧L'],
    ],
    modal: true,
  },

  // ── Groups + schema ─────────────────────────────────────────────────────
  schema: {
    group: 'Reading',
    path: 'Reading',
    desc: 'Books and long reads. Schema applies to every entry here and in nested groups.',
    props: [
      ['author', 'string', '—'],
      ['read', 'boolean', 'false'],
      ['rating', 'number', '—'],
      ['started', 'date', '—'],
      ['finished', 'date', '—'],
      ['genre', 'enum', 'Nonfiction'],
    ],
    enumOptions: ['Fiction', 'Nonfiction', 'Reference'],
    scopedTags: ['to-reread', 'dnf', 'recommend'],
    view: 'note',
  },

  // ── New entry / quick capture ────────────────────────────────────────────
  capture: {
    group: 'Project Atlas',
    schemaProps: [['due', 'date'], ['priority', 'enum'], ['tags', 'tag[]']],
  },

  // ── People directory ──────────────────────────────────────────────────────
  people: [
    { slug: 'sergey', role: 'Maintainer', mentions: 31, last: 'Spec review notes' },
    { slug: 'maya', role: 'Design partner', mentions: 14, last: 'Kickoff sync — Atlas' },
    { slug: 'lee', role: 'Engineering', mentions: 9, last: 'Vendor comparison' },
    { slug: 'rin', role: 'Product', mentions: 6, last: 'Q3 milestones' },
    { slug: 'theo', role: 'Advisor', mentions: 3, last: 'Naming + positioning' },
  ],

  // ── Tags browser ──────────────────────────────────────────────────────────
  tagsGlobal: [
    { n: 'reading', c: 41 }, { n: 'atlas', c: 23 }, { n: 'ideas', c: 17 },
    { n: 'research', c: 15 }, { n: 'spec', c: 12 }, { n: 'meetings', c: 11 }, { n: 'planning', c: 8 },
  ],
  tagsScoped: [
    { n: 'decided', scope: 'Project Atlas', c: 6 },
    { n: 'blocked', scope: 'Project Atlas', c: 3 },
    { n: 'review', scope: 'Project Atlas', c: 5, children: [{ n: 'review/needs', c: 3 }, { n: 'review/done', c: 2 }] },
  ],

  // ── Plugins manager ─────────────────────────────────────────────────────
  plugins: [
    { id: 'kanban-view', title: 'Kanban view', kind: 'processor', on: true, ver: '1.2.0', desc: 'Board rendering for task-list entries.', perms: ['read index'] },
    { id: 'github-issues', title: 'GitHub issues', kind: 'provider', on: true, ver: '0.8.1', desc: 'Pull issues into entries as refs.', perms: ['network', 'write entries'] },
    { id: 'mermaid', title: 'Mermaid diagrams', kind: 'processor', on: false, ver: '2.0.0', desc: 'Render ```mermaid fenced code blocks.', perms: ['read body'] },
    { id: 'ical-import', title: 'iCal import', kind: 'provider', on: false, ver: '0.4.2', desc: 'Import .ics events as dated entries.', perms: ['read files', 'write entries'] },
  ],
};
